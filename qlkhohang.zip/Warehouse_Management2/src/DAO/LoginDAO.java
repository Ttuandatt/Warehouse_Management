/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import DTO.LoginDTO;
import DTO.TaiKhoanDTO;

public class LoginDAO{
    private String dbUrl = "jdbc:mysql://localhost:3306/quanlykhohang";
    private String username = "root";
    private String password = "123456";
    private Connection con;
    
    public boolean openConnection(){
        try{
            con = DriverManager.getConnection(dbUrl, username, password);
            return true;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
    
    public void closeConnection(){
        try{
            if(con!=null)
                con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public LoginDTO checkLogin(LoginDTO user){
        if(openConnection()){
        try{
            String query = "SELECT * FROM taikhoan WHERE taikhoan=? AND matkhau=?";
            PreparedStatement  ps = con.prepareStatement(query);
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ResultSet rs = ps.executeQuery();
            
            if(rs.next()){
                String taikhoan = rs.getString(1);
                String matkhau = rs.getString(2);
                int loai = rs.getInt(3);
                String manv = rs.getString(4);
                return new LoginDTO(username, password, loai, manv);
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            closeConnection();
        }
        }
        return null;
    }
    
    public LoginDTO getAccountInformation(String username, String password){
        LoginDTO userDTO = null;
        if(openConnection()){
            try{
                String query = "SELECT * FROM taikhoan WHERE taikhoan=? AND matkhau=?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1, username);
                ps.setString(2, password);
                ResultSet rs = ps.executeQuery();
                if(rs.next()){
                    int loai  = rs.getInt(3);
                    String manv = rs.getString(4);
                    userDTO = new LoginDTO(username, password, loai, manv);
                }
            }catch(Exception e){
                e.printStackTrace();
            }finally{
                // Không đóng kết nối ở đây
                // closeConnection();
            }
        }
        return userDTO;
    }
}
