/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.PhieuXuatDTO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class PhieuXuatDAO implements DAOInterface<PhieuXuatDTO>{
    private String dbUrl = "jdbc:mysql://localhost:3306/warehouse";
    private String username = "root";
    private String password = "123456";
    private Connection con;
    public boolean openConnection(){
        try{
            con = DriverManager.getConnection(dbUrl, username, password);
            return true;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
    
    public void closeConnection(){
        try{
            if(con!=null)   //con đang kết nối tới database sẽ != null
                con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public ArrayList<PhieuXuatDTO> getAll() {
        ArrayList<PhieuXuatDTO> arr = new ArrayList<>();

        if (openConnection()) {
            try {
                String query = "SELECT * FROM phieuxuat";
                PreparedStatement px = con.prepareStatement(query);
                ResultSet rs = px.executeQuery();
                
                while (rs.next()) {
                    PhieuXuatDTO phieuXuat = new PhieuXuatDTO();
                    phieuXuat.setmapx(rs.getInt(1)); // Assuming 1st column is integer
                    phieuXuat.setnguoitao(rs.getString(2)); // Assuming 2nd column is string
                    phieuXuat.setthoigiantao(rs.getTimestamp(3)); // Assuming 4th column is timestamp
                    phieuXuat.settongtien(rs.getInt(4)); // Assuming 3rd column is double
                    
                    arr.add(phieuXuat);
                }

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                closeConnection();
            }
        }
        return arr;
    }
    @Override
    public boolean has(String mapx){
        boolean result = false;
        if(openConnection()){
            try{
                String query = "SELECT *FROM phieuxuat where mapx = ?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1, Integer.parseInt(mapx));
                ResultSet rs = ps.executeQuery();
                result = rs.next();
            }catch(Exception e){
                e.printStackTrace();
            }finally{
                closeConnection();
            }
    
        }
    
        return result;
    }
    
    @Override
    public boolean add(PhieuXuatDTO px){
        boolean result = false;
        if(openConnection()) {
            try{
                String query = "INSER INTO phieuxuat VALUES(?,?,?)";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1,px.getmapx());
                ps.setString(2, px.getnguoitao());
                ps.setInt(2, px.gettongtien());
                if(ps.executeUpdate()>0)
                    return true;
    
            }catch(Exception e){
                e.printStackTrace();
            }finally{
                closeConnection();
            }
        }
        return result;
    }
   
    
    
    @Override
    public boolean delete(String mapx) {
        boolean result = false;
        if (openConnection()) {
            try {
                String query = "DELETE FROM phieuxuat WHERE mapx = ?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1, Integer.parseInt(mapx));
                if (ps.executeUpdate() > 0) {
                    result = true;
                }
            } catch (Exception e) {
                e.printStackTrace(); // Handle or log the exception
            } finally {
                closeConnection(); // Close database connection
            }
        }   
        return result;
    }

    @Override
    public boolean update(PhieuXuatDTO px){
        boolean result = false;
        if(openConnection()){
            try{
                String query = "UPDATE phieuxuat SET mapx = ? ,nguoitao = ?,tongtien=?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1, px.getmapx());
                ps.setString(2, px.getnguoitao());
                ps.setInt(3,px.gettongtien());
                if(ps.executeUpdate()>0)
                    return true;
            }catch (Exception e) {
                e.printStackTrace();
            } finally{
                closeConnection();
            }
        }

        return result;

    }

    @Override
    public PhieuXuatDTO getByID(String mapx){
        PhieuXuatDTO phieuXuat = null;
        if(openConnection()){
            try{
                String query = "SELECT *FROM phieuxuat WHERE mapx = ?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1,Integer.parseInt(mapx));
                ResultSet rs = ps.executeQuery();
                if(rs.next()){
                    String nguoitao = rs.getString(2);
                    int tongtien = rs.getInt(3);
                }

            }catch (Exception e) {
                e.printStackTrace();
            }finally{
                closeConnection();
            }
        }
        return phieuXuat;

    }

@Override
public ArrayList<PhieuXuatDTO> search(String searchContent){
    ArrayList<PhieuXuatDTO> arr = new ArrayList<>();
    return arr;
}


    
}
