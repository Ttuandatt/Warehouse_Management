/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.PhieuXuatDTO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class PhieuXuatDAO implements DAOInterface<PhieuXuatDTO>{
    private String dbUrl = "jdbc:mysql://localhost:3306/quanlykhohang";
    private String username = "root";
    private String password = "123456";
    private Connection con;
    
    public boolean openConnection(){
        try{
            con = DriverManager.getConnection(dbUrl, username, password);
            return true;
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
    
    public void closeConnection(){
        try{
            if(con!=null)   //con đang kết nối tới database sẽ != null
                con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public ArrayList<PhieuXuatDTO> getAll() {
        ArrayList<PhieuXuatDTO> arr = new ArrayList<>();

        if (openConnection()) {
            try {
                String query = "SELECT * FROM phieuxuat WHERE trangthai = 1";
                PreparedStatement ps = con.prepareStatement(query);
                ResultSet rs = ps.executeQuery();
                
                while (rs.next()) {
                    PhieuXuatDTO pxDTO = new PhieuXuatDTO();
                    pxDTO.setMapx(rs.getInt(1)); 
                    pxDTO.setManguoitao(rs.getString(2)); 
                    pxDTO.setThoigiantao(rs.getTimestamp(3)); 
                    pxDTO.setTongtien(rs.getInt(4)); 
                    
                    arr.add(pxDTO);
                }

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                closeConnection();
            }
        }
        return arr;
    }
    @Override
    public boolean has(String mapx){
        boolean result = false;
        if(openConnection()){
            try{
                String query = "SELECT *FROM phieuxuat where mapx = ?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1, Integer.parseInt(mapx));
                ResultSet rs = ps.executeQuery();   // Trả về 1 đối tượng dạng bảng
                result = rs.next(); // rs.next(): di chuyển con trỏ đến dòng tiếp theo, trả về true nếu di chuyển đến dòng tiếp theo thành công (tức là có từ 1 dòng trở lên), false thì ngược lại
            }catch(Exception e){
                e.printStackTrace();
            }finally{
                closeConnection();
            }
    
        }
    
        return result;
    }
    
    @Override
    public boolean add(PhieuXuatDTO px){
        boolean result = false;
        if(openConnection()) {
            try{
                String query = "INSERT INTO phieuxuat VALUES (?, ?, ?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1, px.getMapx());
                ps.setString(2, px.getManguoitao());
                ps.setTimestamp(3, px.getThoigiantao());
                ps.setInt(4, px.getTongtien());
                ps.setInt(5, 1);
                if(ps.executeUpdate()>0)
                    return true;
    
            }catch(Exception e){
                e.printStackTrace();
            }finally{
                closeConnection();
            }
        }
        return result;
    }
   
    
    
    @Override
    public boolean delete(String mapx) {
        boolean result = false;
        if (openConnection()) {
            try {
                String query = "UPDATE phieuxuat SET trangthai = 0 WHERE mapx = ?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1, Integer.parseInt(mapx));
                if (ps.executeUpdate() > 0) {
                    result = true;
                }
            } catch (Exception e) {
                e.printStackTrace(); // Handle or log the exception
            } finally {
                closeConnection(); // Close database connection
            }
        }   
        return result;
    }

    @Override
    public boolean update(PhieuXuatDTO px){
        boolean result = false;
        if(openConnection()){
            try{
                String query = "UPDATE phieuxuat SET mapx = ? ,manguoitao = ?,tongtien=?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1, px.getMapx());
                ps.setString(2, px.getManguoitao());
                ps.setInt(3,px.getTongtien());
                if(ps.executeUpdate()>0)
                    return true;
            }catch (Exception e) {
                e.printStackTrace();
            } finally{
                closeConnection();
            }
        }

        return result;

    }

    @Override
    public PhieuXuatDTO getByID(String mapx){
        PhieuXuatDTO phieuXuat = null;
        if(openConnection()){
            try{
                String query = "SELECT * FROM phieuxuat WHERE mapx = ?";
                PreparedStatement ps = con.prepareStatement(query);
                ps.setInt(1,Integer.parseInt(mapx));
                ResultSet rs = ps.executeQuery();
                if(rs.next()){
                    String nguoitao = rs.getString(2);
                    int tongtien = rs.getInt(3);
                }

            }catch (Exception e) {
                e.printStackTrace();
            }finally{
                closeConnection();
            }
        }
        return phieuXuat;

    }

@Override
public ArrayList<PhieuXuatDTO> search(String searchContent){
    ArrayList<PhieuXuatDTO> arr = new ArrayList<>();
    return arr;
}


    
}
