package GUI;
import BUS.SanPhamBUS;
import DTO.SanPhamDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class XuatHangGUI extends JPanel {
    public JLabel moneyLabel;
       private JPanel rightPanel;
    private JComboBox<String> providerComboBox;
    private JTable tempTable;
     SanPhamBUS spBUS = new SanPhamBUS();
     JTable table = new JTable();
       ArrayList<SanPhamDTO> arrSanPham = new ArrayList<SanPhamDTO>();
     DefaultTableModel model = new DefaultTableModel();
     DefaultTableModel tempTableModel = new DefaultTableModel();
         JTable table1 = new JTable();
      DefaultTableModel model1 = new DefaultTableModel();
    private JPanel leftPanel;


    public XuatHangGUI() {
        this.setLayout(new GridLayout(1, 2, 10, 10));
        initLeftPanel();
        this.add(leftPanel);
        initRightPanel();
        this.add(rightPanel);
    }

 public void search(DefaultTableModel model, JTextField searchTextField, JTable productTable) {
    String searchText = searchTextField.getText().trim().toLowerCase(); // Get the search text and trim it

    // If the search text is empty, reset the table to display all data
    if (searchText.isEmpty()) {
        productTable.clearSelection();
        loadSanPhamList(model); // Reload all data
        return;
    }

    // Otherwise, filter the data based on the search text
    TableRowSorter<TableModel> sorter = new TableRowSorter<>(model);
    productTable.setRowSorter(sorter);

    // Define the filter
    RowFilter<TableModel, Object> rowFilter = RowFilter.regexFilter("(?i)" + searchText); // Case insensitive filter

    // Apply the filter to the sorter
    sorter.setRowFilter(rowFilter);
}



public void initLeftPanel() {
    this.leftPanel = new JPanel();
    this.leftPanel.setLayout(new BorderLayout());
    this.leftPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 10));

    JPanel searchPanel = new JPanel(new BorderLayout());
    searchPanel.setBorder(BorderFactory.createTitledBorder("Tìm kiếm"));
    JTextField searchTextField = new JTextField();
    JButton searchButton = new JButton("Tìm");
    searchPanel.add(searchTextField, BorderLayout.CENTER);
    searchPanel.add(searchButton, BorderLayout.EAST);

    JPanel productPanel = new JPanel(new BorderLayout());
    productPanel.setBorder(BorderFactory.createTitledBorder("Danh sách sản phẩm"));

    // Create a DefaultTableModel
    DefaultTableModel model = new DefaultTableModel();
    JTable productTable = new JTable(model);
    JScrollPane scrollPane = new JScrollPane(productTable);
    productPanel.add(scrollPane, BorderLayout.CENTER);

    JPanel optionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JLabel quantityLabel = new JLabel("Số lượng:");
    JTextField quantityTextField = new JTextField(5);
    JButton addButton = new JButton("Thêm");
    optionPanel.add(quantityLabel);
    optionPanel.add(quantityTextField);
    optionPanel.add(addButton);

    this.leftPanel.add(searchPanel, BorderLayout.NORTH);
    this.leftPanel.add(productPanel, BorderLayout.CENTER);
    this.leftPanel.add(optionPanel, BorderLayout.SOUTH);

    // Load data into the table
    loadSanPhamList(model);
    addButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRowIndex = productTable.getSelectedRow();
        if (selectedRowIndex != -1) {
            String maSP = productTable.getValueAt(selectedRowIndex, 0).toString();
            String tenSP = productTable.getValueAt(selectedRowIndex, 1).toString();
            String soLuong = productTable.getValueAt(selectedRowIndex, 2).toString();
            String donGia = productTable.getValueAt(selectedRowIndex, 3).toString();
            
            // Calculate the new index
            int newIndex = tempTableModel.getRowCount() + 1;
            
            // Add the data to tempTableModel
            Object[] newRow = {String.valueOf(newIndex), maSP, tenSP, soLuong, donGia};
            tempTableModel.addRow(newRow); // Assuming tempTableModel is the model for tempTable
//            
            double totalPrice = 0.0;
        for (int i = 0; i < tempTableModel.getRowCount(); i++) {
            String donGia1 = tempTableModel.getValueAt(i, 4).toString();
            double donGiaDouble = Double.parseDouble(donGia1);
            totalPrice += donGiaDouble;
        }
        moneyLabel.setText(String.format("%.2f đ", totalPrice)); 

        }
    }
});
 searchButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            search(model, searchTextField, productTable);
        }
    });
}




 public void initRightPanel() {
    this.rightPanel = new JPanel();
    this.rightPanel.setLayout(new BorderLayout());
    this.rightPanel.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 50));

    // North
    JPanel infoPanel = new JPanel();
    infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
    infoPanel.setBorder(BorderFactory.createTitledBorder("Thông tin"));

    JPanel codePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JLabel codeLabel = new JLabel("Mã SP:");
    JTextField codeTextField = new JTextField("ASdhj", 15);
    codeTextField.setEditable(false);
    codePanel.add(codeLabel);
    codePanel.add(codeTextField);

    JPanel providerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JLabel providerLabel = new JLabel("Nhà cung cấp:");
    String[] providerData = {"aksd", "asdad", "asdazxcxczczx", "1321231"};
    providerComboBox = new JComboBox<>(providerData);
    providerPanel.add(providerLabel);
    providerPanel.add(providerComboBox);

    JPanel creatorPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    JLabel creatorLabel = new JLabel("Người tạo:");
    JTextField creatorTextField = new JTextField("Admin", 15);
    creatorTextField.setEditable(false);
    creatorPanel.add(creatorLabel);
    creatorPanel.add(creatorTextField);

    infoPanel.add(codePanel);
    infoPanel.add(providerPanel);
    infoPanel.add(creatorPanel);

    // Center
    JPanel tempPanel = new JPanel();
    tempPanel.setLayout(new BorderLayout());
    String[][] tableData = {};
    String[] columnData = {"STT", "Mã SP", "Tên SP", "Số lượng", "Đơn giá"};
    tempTableModel = new DefaultTableModel(tableData, columnData); // Assign to the class field
    tempTable = new JTable(tempTableModel);
    JScrollPane scrollPane = new JScrollPane(tempTable, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    scrollPane.setVisible(true);

    JPanel optionPanel = new JPanel();
    JButton editQuantityButton = new JButton("Sửa số lượng");
    JButton deleteButton = new JButton("Xóa sản phẩm");
    optionPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
    optionPanel.add(editQuantityButton);
    optionPanel.add(deleteButton);

    tempPanel.add(scrollPane, BorderLayout.CENTER);
    tempPanel.add(optionPanel, BorderLayout.SOUTH);

    // South
    JPanel summaryPanel = new JPanel();
    summaryPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 0));
    JLabel totalLabel = new JLabel("Tổng Tiền:");
     moneyLabel = new JLabel("đ");
    JButton importButton = new JButton("Xuất hàng");
    summaryPanel.add(totalLabel);
    summaryPanel.add(moneyLabel);
    summaryPanel.add(importButton);

    this.rightPanel.add(infoPanel, BorderLayout.NORTH);
    this.rightPanel.add(tempPanel, BorderLayout.CENTER);
    this.rightPanel.add(summaryPanel, BorderLayout.SOUTH);
//

  deleteButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRowIndex = tempTable.getSelectedRow();
        if (selectedRowIndex != -1) {
            tempTableModel.removeRow(selectedRowIndex);
            
            // Update the total price after removing the row
            double totalPrice = 0.0;
            for (int i = 0; i < tempTableModel.getRowCount(); i++) {
                String donGia1 = tempTableModel.getValueAt(i, 4).toString();
                double donGiaDouble = Double.parseDouble(donGia1);
                totalPrice += donGiaDouble;
            }
            moneyLabel.setText(String.format("%.2f đ", totalPrice)); 
        }
    }
});
  editQuantityButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int selectedRowIndex = tempTable.getSelectedRow();
        if (selectedRowIndex != -1) {
            // Get the current quantity from the selected row
            String currentQuantity = tempTableModel.getValueAt(selectedRowIndex, 3).toString();
            
            // Prompt the user to enter the new quantity
            String newQuantityStr = JOptionPane.showInputDialog(null, "Enter new quantity:", currentQuantity);
            
            // If the user entered a new quantity
            if (newQuantityStr != null && !newQuantityStr.isEmpty()) {
                // Update the quantity in the table model
                tempTableModel.setValueAt(newQuantityStr, selectedRowIndex, 3);
                
                // Update the total price after editing the quantity
                double totalPrice = 0.0;
                for (int i = 0; i < tempTableModel.getRowCount(); i++) {
                    String donGia1 = tempTableModel.getValueAt(i, 4).toString();
                    double donGiaDouble = Double.parseDouble(donGia1);
                    totalPrice += donGiaDouble;
                }
                moneyLabel.setText(String.format("%.2f đ", totalPrice)); 
            }
        }
    }
});

}

public void loadSanPhamList(DefaultTableModel model) {
    model.addColumn("Mã máy");
    model.addColumn("Tên máy");
    model.addColumn("Số lượng");
    model.addColumn("Giá");
    arrSanPham = spBUS.getAllSanPham(); // Get data from the database
    for (SanPhamDTO sanpham : arrSanPham) {
        String mamay = sanpham.getMaMay();
        String tenmay = sanpham.getTenMay();
        int soluong = sanpham.getSoLuong();
        int gia = sanpham.getGia();
        Object[] row = {mamay, tenmay, soluong , gia};
        model.addRow(row);
    }
}

    public static void main(String[] args) {
        JFrame frame = new JFrame("Xuat Hang Form");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);

        XuatHangGUI view = new XuatHangGUI();
        frame.add(view);
        frame.setVisible(true);
    }
}




