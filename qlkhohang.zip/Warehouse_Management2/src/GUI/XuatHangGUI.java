package GUI;
import BUS.SanPhamBUS;
import BUS.LoginBUS;
import BUS.PhieuXuatBUS;
import BUS.CTPhieuXuatBUS;
import DTO.CTPhieuXuatDTO;
import DTO.SanPhamDTO;
import DTO.PhieuXuatDTO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.sql.Timestamp;

public class XuatHangGUI extends JPanel {
    private int totalPrice = 0;
    private JTextField tfMaPX, tfNguoiTao;
    private int countAddRow = 0;
    JTextField quantityTextField, searchTextField;
    public JLabel moneyLabel;
    private JPanel rightPanel;
    SanPhamBUS spBUS = new SanPhamBUS();
    PhieuXuatBUS pxBUS = new PhieuXuatBUS();
    CTPhieuXuatBUS ctpxBUS = new CTPhieuXuatBUS();
    JTable table = new JTable();
    JTable table1 = new JTable();
    ArrayList<SanPhamDTO> arrSanPham = new ArrayList<>();
    DefaultTableModel model = new DefaultTableModel();
    DefaultTableModel model1 = new DefaultTableModel();
    private JPanel leftPanel;


    public XuatHangGUI() {
        this.setLayout(new GridLayout(1, 2, 10, 10));
        initLeftPanel();
        this.add(leftPanel);
        initRightPanel();
        this.add(rightPanel);
    }



    public void initLeftPanel() {
        table.setDefaultEditor(Object.class, null);
        leftPanel = new JPanel();
        leftPanel.setLayout(new BorderLayout());
        leftPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 10));

        JPanel searchPanel = new JPanel(new BorderLayout());
        searchPanel.setBorder(BorderFactory.createTitledBorder("Tìm kiếm"));
        searchTextField = new JTextField();
        JButton searchButton = new JButton("Tìm");
        searchPanel.add(searchTextField, BorderLayout.CENTER);
        searchPanel.add(searchButton, BorderLayout.EAST);

        JPanel productPanel = new JPanel(new BorderLayout());
        productPanel.setBorder(BorderFactory.createTitledBorder("Danh sách sản phẩm"));

        // Create a DefaultTableModel
        table.setModel(model);
        JScrollPane scrollPane = new JScrollPane(table);
        productPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel optionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel quantityLabel = new JLabel("Số lượng:");
        quantityTextField = new JTextField(5);
        JButton addButton = new JButton("Thêm");
        optionPanel.add(quantityLabel);
        optionPanel.add(quantityTextField);
        optionPanel.add(addButton);

        this.leftPanel.add(searchPanel, BorderLayout.NORTH);
        this.leftPanel.add(productPanel, BorderLayout.CENTER);
        this.leftPanel.add(optionPanel, BorderLayout.SOUTH);

        // Load data into the table
        loadSanPhamList(model);
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRowIndex = table.getSelectedRow();
                if (selectedRowIndex != -1) {
                    String maSP = table.getValueAt(selectedRowIndex, 0).toString();
                    String tenSP = table.getValueAt(selectedRowIndex, 1).toString();
                    int soLuong = Integer.parseInt(quantityTextField.getText());
                    int donGia = Integer.parseInt(table.getValueAt(selectedRowIndex, 3).toString()); //.getValueAt trả về 1 đối tượng kiểu Object, sau đó ép về String, sau đó ép về int

                    // Calculate the new index
                    int newIndex = model1.getRowCount() + 1;

                    // Add the data to model1
                    Object[] newRow = {String.valueOf(newIndex), maSP, tenSP, soLuong, donGia};
                    model1.addRow(newRow); // Assuming model1 is the model for tempTable

                    int price = 0;
                    price+= donGia * soLuong ;
                    totalPrice += price;

                    moneyLabel.setText(String.format("%d đ", totalPrice)); 
                    countAddRow += 1;

                }
            }
        });
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                search(model, searchTextField, table);
            }
        });
    }




    public void initRightPanel() {
        table1.setDefaultEditor(Object.class,null);
        rightPanel = new JPanel();
        rightPanel.setLayout(new BorderLayout());
        rightPanel.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 50));

        // North
        JPanel infoPanel = new JPanel();
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.setBorder(BorderFactory.createTitledBorder("Thông tin"));

        JPanel codePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel codeLabel = new JLabel("Mã phiếu xuất:");
        tfMaPX = new JTextField(15);
        tfMaPX.setEditable(false);
        tfMaPX.setFocusable(false);
        codePanel.add(codeLabel);
        codePanel.add(tfMaPX);
        PhieuXuatDTO pxDTO = new PhieuXuatDTO();
        tfMaPX.setText("PX" + pxDTO.getMapx());


        JPanel creatorPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel creatorLabel = new JLabel("Người tạo:       ");
        tfNguoiTao = new JTextField(15);
        tfNguoiTao.setEditable(false);
        tfNguoiTao.setFocusable(false);
        creatorPanel.add(creatorLabel);
        creatorPanel.add(tfNguoiTao);
        tfNguoiTao.setText(LoginBUS.id);
        
        infoPanel.add(codePanel);
        infoPanel.add(creatorPanel);

        // Center
        JPanel tempPanel = new JPanel();
        tempPanel.setLayout(new BorderLayout());
        String[][] tableData = {};
        String[] columnData = {"STT", "Mã SP", "Tên SP", "Số lượng", "Đơn giá"};
        model1 = new DefaultTableModel(tableData, columnData); // Assign to the class field
        table1.setModel(model1);
        JScrollPane scrollPane = new JScrollPane(table1, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVisible(true);

        JPanel optionPanel = new JPanel();
        JButton editQuantityButton = new JButton("Sửa số lượng");
        JButton deleteButton = new JButton("Xóa sản phẩm");
        optionPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        optionPanel.add(editQuantityButton);
        optionPanel.add(deleteButton);

        tempPanel.add(scrollPane, BorderLayout.CENTER);
        tempPanel.add(optionPanel, BorderLayout.SOUTH);

        // South
        JPanel summaryPanel = new JPanel();
        summaryPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 0));
        JLabel totalLabel = new JLabel("Tổng tiền:");
        moneyLabel = new JLabel("đ");
        JButton buttonXuatHang = new JButton("Xuất hàng");
        summaryPanel.add(totalLabel);
        summaryPanel.add(moneyLabel);
        summaryPanel.add(buttonXuatHang);

        this.rightPanel.add(infoPanel, BorderLayout.NORTH);
        this.rightPanel.add(tempPanel, BorderLayout.CENTER);
        this.rightPanel.add(summaryPanel, BorderLayout.SOUTH);
        
        buttonXuatHang.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                xuatHangPerformed(table1);
                
            }
        });
        
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRowIndex = table1.getSelectedRow();
                int soLuong = Integer.parseInt(table1.getValueAt(selectedRowIndex, 3).toString());
                int gia = Integer.parseInt(table1.getValueAt(selectedRowIndex, 4).toString());
                if (selectedRowIndex != -1) {
                    model1.removeRow(selectedRowIndex);
                    // Update the total price after removing the row
                    totalPrice -= gia*soLuong;
                    moneyLabel.setText(String.format("%d đ", totalPrice)); 
                }   
            }
        });
        editQuantityButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRowIndex = table1.getSelectedRow();
                if (selectedRowIndex != -1) {
                    // Get the current quantity from the selected row
                    String currentQuantity = model1.getValueAt(selectedRowIndex, 3).toString();
                    
                    // Prompt the user to enter the new quantity
                    String newQuantityStr = JOptionPane.showInputDialog(null, "Enter new quantity:", currentQuantity);
                    
                    // If the user entered a new quantity
                    if (newQuantityStr != null && !newQuantityStr.isEmpty()) {
                        int soLuongHienTai = Integer.parseInt(currentQuantity);
                        int soLuongMoi = Integer.parseInt(newQuantityStr);
                        // Update the quantity in the table model
                        model1.setValueAt(soLuongMoi, selectedRowIndex, 3);
                        String donGiaStr = model1.getValueAt(selectedRowIndex, 4).toString();
                        int donGia = Integer.parseInt(donGiaStr);
                        totalPrice -= donGia*soLuongHienTai;
                        totalPrice += donGia*soLuongMoi;

                        moneyLabel.setText(String.format("%d", totalPrice)); 
                    }
                }
            }
        });

    }

    public void loadSanPhamList(DefaultTableModel model) {
        table1.setModel(model1);
        model.addColumn("Mã máy");
        model.addColumn("Tên máy");
        model.addColumn("Số lượng");
        model.addColumn("Giá");
        model.addColumn("Kho");
        arrSanPham = spBUS.getAllSanPham(); // Get data from the database
        for (SanPhamDTO sanpham : arrSanPham) {
            String mamay = sanpham.getMaMay();
            String tenmay = sanpham.getTenMay();
            int soluong = sanpham.getSoLuong();
            int gia = sanpham.getGia();
            String kho = sanpham.getMaKho();
            Object[] row = {mamay, tenmay, soluong , gia, kho};
            model.addRow(row);
        }
    }
    
    public void search(DefaultTableModel model, JTextField searchTextField, JTable productTable) {
        String searchText = searchTextField.getText().trim().toLowerCase(); // Get the search text and trim it

        // If the search text is empty, reset the table to display all data
        if (searchText.isEmpty()) {
            productTable.clearSelection();
            loadSanPhamList(model1); // Reload all data
            return;
        }

        // Otherwise, filter the data based on the search text
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(model);
        productTable.setRowSorter(sorter);

        // Define the filter
        RowFilter<TableModel, Object> rowFilter = RowFilter.regexFilter("(?i)" + searchText); // Case insensitive filter

        // Apply the filter to the sorter
        sorter.setRowFilter(rowFilter);
    }

    private void xuatHangPerformed(JTable tb){
            int dialogResult = JOptionPane.showConfirmDialog(null,"Bạn có chắc muốn xuất hàng?");
            if(dialogResult == JOptionPane.OK_OPTION){
                // Lấy mã phiếu xuất, mã người tạo, và tổng tiền từ giao diện
                String mapxText = tfMaPX.getText();
                int mapx = Integer.parseInt(mapxText.substring(2)); // Bỏ tiền tố "PX"
                String maNguoiTao = tfNguoiTao.getText();
                Timestamp tgiantao = new Timestamp(System.currentTimeMillis()); // Lấy thời gian hiện tại và tạo một đối tượng Timestamp
//                int tongtien = totalPrice; // Tổng tiền hiện đang được cập nhật trong `totalPrice`
                // In ra giá trị của totalPrice để kiểm tra
                System.out.println("Total Price: " + totalPrice);
                
                // Tạo một đối tượng DTO cho phiếu nhập
                PhieuXuatDTO pxDTO = new PhieuXuatDTO(mapx, maNguoiTao, tgiantao, totalPrice);
                // Gọi phương thức thêm phiếu nhập vào cơ sở dữ liệu
                String resultPX = pxBUS.addPhieuXuat(pxDTO);
                String resultCTPX = "";
                for(int i=0;i<countAddRow;i++){
                    String masp = table1.getValueAt(i, 1).toString();
                    String tensp = table1.getValueAt(i, 2).toString();
                    int soluong = Integer.parseInt(table1.getValueAt(i, 3).toString());
                    int gia = Integer.parseInt(table1.getValueAt(i, 4).toString());
                    CTPhieuXuatDTO ctpxDTO = new CTPhieuXuatDTO(mapx, maNguoiTao, tgiantao,masp, tensp, soluong, gia);
                    resultCTPX = ctpxBUS.addCTPhieuXuat(ctpxDTO);
                }
                System.out.println(countAddRow);
                
//                
                
                
                // Xử lý kết quả và thông báo cho người dùng
                if (resultPX.equals("Thêm px thành công") && resultCTPX.equals("Thêm chi tiết phiếu xuất thành công")) {
                    JOptionPane.showMessageDialog(null, "Xuất hàng thành công!");
                    // Có thể reset giao diện hoặc cập nhật lại giao diện nếu cần
                } else {
                    JOptionPane.showMessageDialog(null, "Xuất hàng thất bại: " + resultPX);
                }
            }
            
    }
    
    public static void main(String[] args) {
        JFrame frame = new JFrame("Xuat Hang Form");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);

        XuatHangGUI view = new XuatHangGUI();
        frame.add(view);
        frame.setVisible(true);
    }
}




