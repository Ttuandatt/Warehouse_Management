/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author ACER
 */
public class TaiKhoanDTO {
    private String taikhoan;
    private String matkhau;
    private int loai;
    private String manv;
    
    public TaiKhoanDTO(){
        
    }
    
    public TaiKhoanDTO(String taikhoan, String matkhau, int loai, String manv){
        this.taikhoan = taikhoan;
        this.matkhau = matkhau;
        this.loai = loai;
        this.manv = manv;
    }
    
    public String getTaiKhoan(){
        return this.taikhoan;
    }
    
    public void setTaiKhoan(String taikhoan){
        this.taikhoan = taikhoan;
    }
    
    public String getMatKhau(){
        return this.matkhau;
    }
    
    public void setMatKhau(String matkhau){
        this.matkhau = matkhau;
    }
    
    public int getLoai(){
        return this.loai;
    }
    
    public void setLoai(int loai){
        this.loai = loai;
    }
    
    public String getMaNv(){
        return this.manv;
    }
    
    public void setMaNV(String manv){
        this.manv = manv;
    }
}

