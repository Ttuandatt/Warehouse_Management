package DTO;

public class CTPhieuNhapDTO {
	private String mapn;
	private String masp;
	private String tensp;
	private int soluong;
	private int tongtien;
	public CTPhieuNhapDTO() {
		
	}
	public CTPhieuNhapDTO(String mapn, String masp, String tensp, int soluong, int tongtien) {
		super();
		this.mapn = mapn;
		this.masp = masp;
		this.tensp = tensp;
		this.soluong = soluong;
		this.tongtien = tongtien;
	}
	public String getMapn() {
		return mapn;
	}
	public void setMapn(String mapn) {
		this.mapn = mapn;
	}
	public String getMasp() {
		return masp;
	}
	public void setMasp(String masp) {
		this.masp = masp;
	}
	public String getTensp() {
		return tensp;
	}
	public void setTensp(String tensp) {
		this.tensp = tensp;
	}
	public int getSoluong() {
		return soluong;
	}
	public void setSoluong(int soluong) {
		this.soluong = soluong;
	}
	public int getTongtien() {
		return tongtien;
	}
	public void setTongtien(int tongtien) {
		this.tongtien = tongtien;
	}
	
}