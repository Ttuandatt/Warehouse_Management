/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.sql.Timestamp;
import java.util.ArrayList;

/**
 *
 * @author PC
 */
public class PhieuXuatDTO {
    private int mapx;
    private String nguoitao;
    private int tongtien;
    private Timestamp thoigiantao; 
    private ArrayList<ChiTietPhieuXuatDTO> ctPhieuXuat;

    public PhieuXuatDTO() {}

    public PhieuXuatDTO(int mapx, String nguoitao, int tongtien, Timestamp thoigiantao, ArrayList<ChiTietPhieuXuatDTO> ctPhieuXuat) {
        this.mapx = mapx;
        this.nguoitao = nguoitao;
        this.tongtien = tongtien;
        this.thoigiantao = thoigiantao;
        this.ctPhieuXuat = ctPhieuXuat;
    }

    public int getmapx() {
        return mapx;
    }

    public void setmapx(int mapx) {
        this.mapx = mapx;
    }

    public String getnguoitao() {
        return nguoitao;
    }

    public void setnguoitao(String nguoitao) {
        this.nguoitao = nguoitao;
    }

    public int gettongtien() {
        return tongtien;
    }

    public void settongtien(int tongtien) {
        this.tongtien = tongtien;
    }

    public Timestamp getthoigiantao() {
        return thoigiantao;
    }

    public void setthoigiantao(Timestamp thoigiantao) {
        this.thoigiantao = thoigiantao;
    }

    public ArrayList<ChiTietPhieuXuatDTO> getCtPhieuXuat() {
        return ctPhieuXuat;
    }

    public void setCtPhieuXuat(ArrayList<ChiTietPhieuXuatDTO> ctPhieuXuat) {
        this.ctPhieuXuat = ctPhieuXuat;
    }
}
