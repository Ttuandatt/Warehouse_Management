/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.sql.Timestamp;
import java.util.ArrayList;

/**
 *
 * @author PC
 */
public class PhieuXuatDTO {
    private int mapx;
    private String manguoitao;
    private Timestamp thoigiantao; 
    private int tongtien;
    private int trangThai;
//    private ArrayList<CTPhieuXuatDTO> ctPhieuXuat;

    public PhieuXuatDTO() {}

    public PhieuXuatDTO(int mapx, String manguoitao, Timestamp thoigiantao, int tongtien, int trangThai) {
        this.mapx = mapx;
        this.manguoitao = manguoitao;
        this.thoigiantao = thoigiantao;
        this.tongtien = tongtien;
        this.trangThai = trangThai;
    }
    
    public PhieuXuatDTO(int mapx, String manguoitao, Timestamp thoigiantao, int tongtien) {
        this.mapx = mapx;
        this.manguoitao = manguoitao;
        this.thoigiantao = thoigiantao;
        this.tongtien = tongtien;

    }
    
    public PhieuXuatDTO(int mapx, String manguoitao, Timestamp thoigiantao) {
        this.mapx = mapx;
        this.manguoitao = manguoitao;
        this.thoigiantao = thoigiantao;
    }


    public int getMapx() {
        return mapx;
    }

    public void setMapx(int mapx) {
        this.mapx = mapx;
    }

    public String getManguoitao() {
        return manguoitao;
    }

    public void setManguoitao(String manguoitao) {
        this.manguoitao = manguoitao;
    }

    public Timestamp getThoigiantao() {
        return thoigiantao;
    }

    public void setThoigiantao(Timestamp thoigiantao) {
        this.thoigiantao = thoigiantao;
    }

    public int getTongtien() {
        return tongtien;
    }

    public void setTongtien(int tongtien) {
        this.tongtien = tongtien;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }
}
