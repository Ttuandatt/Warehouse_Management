/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BUS;

import DAO.PhieuXuatDAO;
import DTO.PhieuXuatDTO;
import java.util.ArrayList;

/**
 *
 * @author PC
 */
public class PhieuXuatBUS {
    PhieuXuatDAO pxDAO = new PhieuXuatDAO();
    public ArrayList<PhieuXuatDTO> getAllPhieuXuat(){
        return pxDAO.getAll();  
    }
    public String addPhieuXuat(PhieuXuatDTO px){
        if(pxDAO.has(String.valueOf(px.getmapx())))
            return "Mã phiếu xuất tồn tại";
        if(pxDAO.add(px))
            return "Thêm thành công";
        return "Thất bại";
    }
    
    public String xoaPhieuXuat(int mapx){
        if(pxDAO.delete(String.valueOf(mapx)))
            return "Xoá phiếu xuất thành công";
        return "Xoá sản phẩm thất bại1";
    }
    public String updatePhieuXuat(PhieuXuatDTO px){
        if(pxDAO.update(px))
            return "Cập nhật thành công";
        return "Cập nhật thất bại";
    }
    
    
    
    
    
    
    
    
    
    
    
}
