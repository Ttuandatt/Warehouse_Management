package BUS;

import java.util.ArrayList;

import DAO.PhieuNhapDAO;
import DTO.PhieuNhapDTO;

public class PhieuNhapBUS {
	PhieuNhapDAO pnDAO=new PhieuNhapDAO();
	public ArrayList<PhieuNhapDTO> getAllPhieuNhap(){
		return pnDAO.getAll();
	}
	public int getSoLuongPhieu() {
		return pnDAO.countPhieuNhap();
	}
	public void add(PhieuNhapDTO phieunhap) {
		pnDAO.add(phieunhap);
	}
}