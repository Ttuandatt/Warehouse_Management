/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BUS;

import DAO.LoginDAO;
import DAO.NhanVienDAO;
import DAO.TaiKhoanDAO;
import DTO.LoginDTO;
import DTO.NhanVienDTO;
import GUI.LoginGUI;
import GUI.NhanVienKhoView;
import GUI.QuanLyKhoView;
import javax.swing.JOptionPane;

public class LoginBUS {
    private LoginDAO loginDAO;
    private NhanVienDAO nvDAO = new NhanVienDAO();
    public static String hoten = "";
    public static String id = "";
    public static int loai;
    public LoginBUS(){
        this.loginDAO = new LoginDAO();
    }
    
    public void checkAndLogin(LoginDTO user, LoginGUI view){
        try{
            if(loginDAO.openConnection()){
                LoginDTO loggedInUser = loginDAO.checkLogin(user);
                if(loggedInUser != null){
                    if(loggedInUser.getLoai()==0){
                        QuanLyKhoView qlk = new QuanLyKhoView();
                        LoginDTO account = loginDAO.getAccountInformation(user.getUsername(), user.getPassword());
                        String manv = account.getManv();
                        NhanVienDTO thongTinUser = nvDAO.getByID(manv);
//                        hoten = thongTinUser.getTennv();
//                        id = thongTinUser.getManv();
//                        loai = thongTinUser.getLoai();
                        qlk.capNhatThongTinNguoiDung(thongTinUser.getTennv(), thongTinUser.getManv(), thongTinUser.getLoai());
                        view.closeLoginFrame();
                    }
                    else if(loggedInUser.getLoai()==1){
                        NhanVienKhoView nvk = new NhanVienKhoView();
                        nvk.khoiTaoGiaoDien();
                        String username = user.getUsername();
                        String password = user.getPassword();
                        LoginDTO login = loginDAO.getAccountInformation(username, password);
                        String id = login.getManv();
                        NhanVienDTO thongTinUser = nvDAO.getByID(id);
                        hoten = thongTinUser.getTennv();
                        id = thongTinUser.getManv();
                        loai = thongTinUser.getLoai();
                        view.closeLoginFrame();
                    }
                }
                else
                    JOptionPane.showMessageDialog(null, "Tài khoản hoặc mật khẩu không đúng");
                loginDAO.closeConnection();
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Lỗi", "Thông báo", JOptionPane.WARNING_MESSAGE);
        }
    }
    
}
