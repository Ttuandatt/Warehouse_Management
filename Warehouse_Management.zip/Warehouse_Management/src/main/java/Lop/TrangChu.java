/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lop;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author ACER
 */
public class TrangChu extends JPanel {
    //Constructor
    public TrangChu(){
        setBackground(Color.decode("#6c757d"));
        JLabel greeting = new JLabel("HELLO, ĐÂY LÀ CLASS TRANG CHỦ");
        greeting.setForeground(Color.WHITE);
        add(greeting);
    }
}
