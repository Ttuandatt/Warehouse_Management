/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author ACER
 */
public class TitledBorderExample {
    public static void main(String[] args) {
        // Create a panel to hold components
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Create a border for the titled border
        Border border = new LineBorder(Color.BLUE); // Example border style

        // Create a titled border with the specified border and title
        TitledBorder titledBorder = BorderFactory.createTitledBorder(border, "Tiêu đề"); // "Tiêu đề" is Vietnamese for "Title"

        // Set the font and other properties of the titled border if needed
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 14));
        titledBorder.setTitleColor(Color.RED);

        // Set the titled border to the panel
        panel.setBorder(titledBorder);

        // Add some components to the panel
        JLabel label = new JLabel("Nội dung"); // "Nội dung" is Vietnamese for "Content"
        panel.add(label, BorderLayout.CENTER);

        // Create a frame to hold the panel
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Set the gap between the border and the frame
//        frame.getContentPane().setBorder(BorderFactory.createEmptyBorder(100, 100, 100, 100)); // 100 pixels top, right, bottom, left

        frame.add(panel);
        frame.setSize(400, 300); // Increased frame size to accommodate padding
        frame.setVisible(true);
    }
}
