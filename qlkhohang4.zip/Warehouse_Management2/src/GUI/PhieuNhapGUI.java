package GUI;

import java.time.*;
import BUS.LoginBUS;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.EventListener;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import BUS.KhoHangBUS;
import BUS.NhaCungCapBUS;
import BUS.PhieuNhapBUS;
import BUS.SanPhamBUS;
import DTO.CTPhieuNhapDTO;
import DTO.KhoHangDTO;
import DTO.NhaCungCapDTO;
import DTO.PhieuNhapDTO;
import DTO.SanPhamDTO;
import Lop.PopupKhoHang;
import Lop.PopupPhieuNhap;
import BUS.*;

public class PhieuNhapGUI extends JPanel {
	private JPanel rightPanel;
	private JPanel leftPanel;
	private JTextArea searchTextArea;
	private JComboBox<String> searchOption;
	private JTable importTable, importDetailTable;
        private DefaultTableModel importModel, importDetailModel;
	private JTextArea detailSearchTextArea;
	private JComboBox<String> detailSearchOption;
//	private JTable detailTable;
        

	public PhieuNhapGUI() {
		initComponents();
	}

	public void initComponents() {
		this.setLayout(new GridLayout(1, 2, 10, 10));
		initLeftPanel();
		this.add(leftPanel);
		initRightPanel();
		this.add(rightPanel);

	}

	public void initLeftPanel() {
		leftPanel = new JPanel();
		leftPanel.setLayout(new BorderLayout(10, 10));

		JPanel searchPanel = new JPanel();
		searchPanel.setBorder(BorderFactory.createTitledBorder("Tìm kiếm"));
		searchTextArea = new JTextArea(1, 42);
		InputMap inpMap = searchTextArea.getInputMap(JComponent.WHEN_FOCUSED);
		ActionMap actionMap = searchTextArea.getActionMap();
		KeyStroke enterStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
		inpMap.put(enterStroke, enterStroke.toString());
		actionMap.put(enterStroke.toString(), new AbstractAction() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

			}

		});
		String[] searchLabel = { "Mã Phiếu", "Mã người tạo ", "Mã nhà cung cấp", "Giá < value", "Giá = value",
				"Giá > value", "Ngày tạo > value", "Ngày tạo < value", "Ngày tạo = value" };
		searchOption = new JComboBox<String>(searchLabel);

		searchOption.setPreferredSize(new Dimension(100, 20));
		searchOption.setBorder(BorderFactory.createLineBorder(Color.decode("#C1C5BE"), 1));
		searchOption.setSelectedIndex(0);
		searchOption.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}

		});
		searchPanel.add(searchTextArea);
		searchPanel.add(searchOption);

		JPanel tablePanel = new JPanel();
		tablePanel.setLayout(new GridLayout(1, 1));
		tablePanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		ArrayList<PhieuNhapDTO> listCT = new PhieuNhapBUS().getAllPhieuNhap();
		String[] columnData = { "Mã phiếu", "Mã kho ", "Mã ngtao", "Mã ncc", "Ngày tạo", "Tổng tiền" };
		importModel = new DefaultTableModel(columnData, 30);
		importTable = new JTable(importModel);
		DefaultTableModel model = (DefaultTableModel) importTable.getModel();
		model.setRowCount(0);
		;
		for (int i = 0; i < listCT.size(); i++) {
			String mapn = listCT.get(i).getMaphieu();
			String makho = listCT.get(i).getMakho();
			String mangtao = listCT.get(i).getManguoitao();
			String mancc = listCT.get(i).getMancc();
			String ngaytao = listCT.get(i).getNgaytao().toString();
			String tongtien = NumberFormat.getInstance().format(listCT.get(i).getTongtien());
			model.addRow(new Object[] { mapn, makho, mangtao, mancc, ngaytao, tongtien });
		}
		importTable.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() >= 1) {

				}
			}
		});
		importTable.repaint();
		importTable.setDefaultEditor(Object.class, null);
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		TableColumnModel tableCol = importTable.getColumnModel();
		tableCol.getColumn(0).setPreferredWidth(100);
		tableCol.getColumn(1).setPreferredWidth(20);
		tableCol.getColumn(2).setPreferredWidth(20);
		tableCol.getColumn(3).setPreferredWidth(20);
		tableCol.getColumn(4).setPreferredWidth(20);
		tableCol.getColumn(5).setPreferredWidth(20);
		tableCol.getColumn(0).setCellRenderer(centerRenderer);
		tableCol.getColumn(1).setCellRenderer(centerRenderer);
		tableCol.getColumn(2).setCellRenderer(centerRenderer);
		tableCol.getColumn(3).setCellRenderer(centerRenderer);
		tableCol.getColumn(4).setCellRenderer(centerRenderer);
		tableCol.getColumn(5).setCellRenderer(centerRenderer);
		JScrollPane scrollPane = new JScrollPane(importTable, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setVisible(true);

		tablePanel.add(scrollPane);

		JPanel btnPanel = new JPanel();
		btnPanel.setLayout(new FlowLayout());
		btnPanel.setBorder(BorderFactory.createEmptyBorder(0, 200, 15, 200));
		btnPanel.setLayout(getLayout());
		JButton viewButton = new JButton("Xem chi tiết");
                
		JButton deleteButton = new JButton("Xóa");

		btnPanel.add(viewButton);
//		btnPanel.add(whitespaceLabel);
		btnPanel.add(deleteButton);

		leftPanel.add(searchPanel, BorderLayout.NORTH);
		leftPanel.add(tablePanel, BorderLayout.CENTER);
		leftPanel.add(btnPanel, BorderLayout.SOUTH);
	}

	public void initRightPanel() {
		rightPanel = new JPanel();

		rightPanel.setLayout(new BorderLayout());
		

		JPanel searchDetailPanel = new JPanel();
		searchDetailPanel.setBorder(BorderFactory.createTitledBorder("Tìm kiếm"));
		String[] searchDetailData = { "Mã SP", "Tên SP", "Số lượng", "Đơn giá" };
		detailSearchOption=new JComboBox<String>(searchDetailData);
		detailSearchOption.setBorder(BorderFactory.createLineBorder(Color.decode("#C1C5BE"), 1));
		detailSearchOption.setSelectedIndex(0);
		detailSearchOption.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {

                    }

		});
		detailSearchTextArea=new JTextArea(1,42);
		InputMap inpMap = detailSearchTextArea.getInputMap(JComponent.WHEN_FOCUSED);
		ActionMap actionMap = detailSearchTextArea.getActionMap();
		KeyStroke enterStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
		inpMap.put(enterStroke, enterStroke.toString());
		actionMap.put(enterStroke.toString(), new AbstractAction() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
			}

		});
		searchDetailPanel.add(detailSearchTextArea);
		searchDetailPanel.add(detailSearchOption);
		
		JPanel detailTablePanel= new JPanel();

		
		
		rightPanel.add(searchDetailPanel,BorderLayout.NORTH);
	}

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(1000, 1000);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		PhieuNhapGUI view = new PhieuNhapGUI();
		frame.add(view);

	}
}