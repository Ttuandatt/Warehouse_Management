package BUS;
import DAO.*;
import DTO.*;
import java.util.ArrayList;
public class CTPhieuNhapBUS {
	CTPhieuNhapDAO ctpnDAO = new CTPhieuNhapDAO();
	public void add(CTPhieuNhapDTO ctpn) {
		ctpnDAO.add(ctpn);
	}
	public ArrayList<CTPhieuNhapDTO> getAllByID(String mapn){
		return ctpnDAO.getAllByID(mapn);
	}

}